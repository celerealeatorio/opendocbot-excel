# Bridge VBA do OpenDocBot para Excel

Este diretório contém uma versão reduzida para Excel desktop. Ele não é uma conversão completa do agente Office.js.

## O que esta versão faz

- cria a planilha `OpenDocBot_Config`;
- envia a seleção atual e um pedido para um endpoint compatível com OpenAI Chat Completions;
- grava a resposta em uma planilha de saída;
- pode ser ligado a uma Ribbon personalizada por `customUI14.xml`.

## O que ela não faz

Não implementa paridade com o projeto original: não há taskpane, streaming SSE, ciclo de tool calls, edição estruturada de células pela IA, MCP, skills, anexos, OCR, aprovação humana por ação ou sandbox Office.js.

## Instalação manual

1. Abra uma pasta de trabalho habilitada para macro (`.xlsm`) ou um suplemento (`.xlam`).
2. Pressione `Alt+F11`.
3. No editor VBA, use **Arquivo > Importar arquivo** e selecione `OpenDocBotExcel.bas`.
4. Execute `OpenDocBot_InstallConfig` uma vez.
5. Preencha `OpenDocBot_Config!B2:B4`:
   - `B2`: URL completa do endpoint, por exemplo `https://api.openai.com/v1/chat/completions`;
   - `B3`: chave da API;
   - `B4`: nome do modelo;
   - `B5`: nome da planilha onde as respostas serão gravadas.
6. Se quiser um botão na Ribbon, insira `customUI14.xml` no pacote `.xlam` usando uma ferramenta de Ribbon XML. O arquivo contém callbacks que devem existir no módulo VBA.
7. Para transformar em suplemento: **Arquivo > Salvar como > Suplemento do Excel (*.xlam)**. Depois, em **Arquivo > Opções > Suplementos > Gerenciar Suplementos do Excel > Ir**, marque o suplemento.

## Segurança

Não distribua um arquivo com a chave gravada. A chave fica em uma célula e pode ser lida por macros ou por usuários com acesso ao arquivo. Para uso real em equipe, prefira o suplemento Office.js com BYOK local, política corporativa e HTTPS.
