Attribute VB_Name = "OpenDocBotRibbon"
Option Explicit

Private mRibbon As Object

Public Sub OpenDocBot_RibbonLoaded(ByVal ribbon As Object)
    Set mRibbon = ribbon
End Sub

Public Sub OpenDocBot_RibbonAsk(ByVal control As Object)
    OpenDocBot_Ask
End Sub

Public Sub OpenDocBot_RibbonConfig(ByVal control As Object)
    OpenDocBot_InstallConfig
End Sub
