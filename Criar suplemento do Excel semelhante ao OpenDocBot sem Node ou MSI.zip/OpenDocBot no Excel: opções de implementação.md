# OpenDocBot no Excel: opções de implementação

## Conclusão executiva

O projeto anexado já é um suplemento Office.js com painel lateral (`taskpane`) e manifesto para Word, Excel e PowerPoint. A forma correta de instalá-lo no Excel sem Node.js e sem MSI no computador do usuário é:

1. hospedar os arquivos estáticos compilados em HTTPS;
2. instalar/sideloadar o `manifest.xml` no Excel;
3. fixar o suplemento na faixa de opções.

O Node.js é necessário apenas na etapa de desenvolvimento/build ou no servidor que hospeda o suplemento. O usuário final não precisa instalar Node, MSI, DLL ou ActiveX.

## Comparação

| Opção | Instalação final | Barra do Excel | Poder equivalente ao projeto | Limitações |
|---|---|---:|---:|---|
| **Office.js / Web Add-in** | Manifesto XML | Sim, taskpane | **Mais alta** | Excel precisa aceitar Office Add-ins; a página precisa estar em HTTPS |
| **VBA `.xlam`** | Abrir/Adicionar suplemento | Sim, com Ribbon XML | Baixa/média | Sem taskpane nativo, streaming e sandbox; JSON/HTTP e segurança ficam frágeis; MCP/OCR/anexos não ficam equivalentes |
| **VSTO/COM** | MSI ou ClickOnce normalmente | Sim | Alta no Windows desktop | Não atende ao requisito de evitar MSI; não funciona no Excel Web |
| **Office Scripts** | Script na nuvem | Não é um suplemento de Ribbon completo | Baixa | Depende de Microsoft 365/Automate; não é um agente local contínuo |

## Recomendação

Usar o núcleo atual do OpenDocBot como suplemento Office.js focado no Excel. Ele já possui:

- laço iterativo do agente com até 100 iterações;
- ferramentas de leitura, escrita, formatação, ordenação, mesclagem, limpeza e ajuste de linhas/colunas;
- estado da pasta de trabalho e seleção atual;
- aprovação humana antes de alterações;
- modo de sugestões;
- provedores OpenAI-compatible, Anthropic, Gemini, Ollama e outros;
- MCP, skills e execução controlada de Office.js;
- painel lateral React já pronto.

A diferença entre “não usar Node” e “não exigir Node do usuário” é importante: o usuário final não precisa de Node. Para publicar uma nova versão, alguém ainda precisa gerar `dist/` usando o pipeline atual ou receber um build pronto.

## Como instalar sem Node/MSI no usuário

### Microsoft 365 com sideload individual

1. Disponibilize `dist/` em um endereço HTTPS estável.
2. Ajuste no manifesto `manifest.xml` os endereços de `SourceLocation` e dos ícones.
3. No Excel, abra **Página Inicial > Suplementos > Mais Suplementos > Meus Suplementos > Carregar Meu Suplemento**.
4. Selecione o `manifest.xml`.
5. Abra o suplemento, fixe o painel e use o botão na faixa de opções.

### Implantação central

Um administrador pode carregar o manifesto no centro de administração do Microsoft 365. Isso permite disponibilizar o suplemento para usuários ou grupos sem MSI e sem instalação local.

## O que precisaria ser feito para foco exclusivo no Excel

- remover do manifesto os hosts Word e PowerPoint, se desejado;
- manter somente as ferramentas Excel no registro de ferramentas;
- adaptar textos, ícones e comandos da Ribbon para português;
- definir uma URL HTTPS de produção no manifesto;
- validar os API sets mínimos do Excel na versão de Microsoft 365 usada;
- publicar uma versão compilada e testar leitura, edição e confirmação em uma pasta real.

## Por que VBA não fica idêntico

VBA consegue ler e alterar células com o modelo de objetos do Excel e consegue fazer HTTP com `WinHttpRequest` em alguns ambientes. Porém, para reproduzir o OpenDocBot completo, seria necessário reimplementar em VBA:

- serialização JSON e parsing de respostas/tool calls;
- o laço de agente com múltiplas chamadas e histórico;
- streaming SSE;
- todas as definições de ferramentas e validações;
- aprovação humana e recuperação de erros;
- MCP/OAuth;
- anexos, PDF/OCR e armazenamento seguro de chaves;
- sandbox para execução controlada;
- uma interface de chat persistente.

Isso seria uma reescrita grande, mais difícil de manter e com uma superfície de segurança pior. O módulo VBA incluído neste pacote é um **bridge de consulta**: ele envia a seleção atual e um pedido para um endpoint compatível com OpenAI e grava a resposta em uma planilha. Ele não deve ser descrito como paridade total.

## Licenciamento

Antes de redistribuir ou renomear o produto, leia o `LICENSE` do projeto. A licença incluída preserva a marca OpenDocBot e limita o uso corporativo/comercial a 30 usuários em uma janela móvel de 30 dias, salvo acordo comercial separado.
