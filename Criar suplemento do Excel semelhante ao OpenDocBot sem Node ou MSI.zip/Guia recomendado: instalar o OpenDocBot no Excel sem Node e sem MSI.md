# Guia recomendado: instalar o OpenDocBot no Excel sem Node e sem MSI

## Resposta direta

Sim, é possível colocar o OpenDocBot na faixa de opções do Excel sem instalar Node.js e sem usar MSI no computador do usuário. O projeto enviado já segue o modelo correto: **Office Add-in com taskpane**.

O usuário final recebe apenas o `manifest.xml` e o suplemento hospedado em HTTPS. O Excel carrega o painel lateral e o botão fica disponível em **Página Inicial > Suplementos**. Depois, o usuário pode fixar o painel.

## Requisitos

- Microsoft 365 desktop ou Excel para a Web;
- uma URL HTTPS para os arquivos compilados do suplemento;
- um manifesto com `SourceLocation` apontando para essa URL;
- um provedor de IA acessível pelo navegador, ou Ollama/endpoint compatível configurado conforme a rede.

O projeto informa que Office perpétuo 2016/2019/2021 não é suportado pelo desenho atual.

## Fluxo recomendado

```text
Excel -> manifesto XML -> taskpane HTTPS -> OpenDocBot/Office.js
                                      -> provedor de IA escolhido pelo usuário
                                      -> Excel.js para ler/escrever a pasta de trabalho
```

## Escolha entre as duas versões

### Versão recomendada: Office.js

Use o código principal do projeto. É a única opção desta lista que mantém o modelo de ferramenta do projeto, o estado da pasta de trabalho, o painel de chat e as confirmações antes de alterações.

### Versão alternativa: VBA

Use `vba/OpenDocBotExcel.bas` somente quando o ambiente exigir macros e Excel desktop. Ela envia a seleção para uma API e grava a resposta em uma planilha. É uma ponte de consulta, não uma porta equivalente do agente.

## Próximo passo de desenvolvimento

Para entregar uma versão final somente para Excel, o trabalho deve:

1. criar um manifesto de produção exclusivo para `Workbook`;
2. trocar os URLs locais do manifesto por HTTPS de produção;
3. compilar o front-end uma vez e publicar o diretório `dist/`;
4. manter somente as ferramentas `src/tools/excel/*` no registro;
5. testar as operações de leitura, escrita, formatação, ordenação e verificação;
6. validar a instalação por sideload e por implantação central;
7. revisar licença, marca e limite de usuários antes de distribuir.
